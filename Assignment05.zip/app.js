
//                              Chapter - 1 Alert

// Task- 1
// window.alert("Welcome to JavaScript")


// Task-2
// window.alert("Erorr ! Please enter a valid password")

// Task-3
// window.alert("Welcome to JS Land \n Happy Coding ! ")

// Task-4
// window.alert("Welcome to JS Land")

// Task-5
// window.alert("\n Happy Coding !")   

// Task-5 (Half-Incomplete Confused )

// Task-6
// console.log("Q6\n Hello I can run JS through my web browser's console")




//                      Chapter - 2 Variables for Strings


// Task - 1
// var username;

// Task - 2
// var Myname = "Sadiq Shah";


// Task - 3
// var Message = "Hello World";
// alert(Message)

// Task - 4

// stdName = "Sadiq shah";
// window.alert("Student Name is " + " " + stdName)

// stdage = "23 year old";
// window.alert("Student Age is " + " " + stdage)

// stdCourse = "Certified Mobile Application Development";
// window.alert("Student Course is " + " " + stdCourse);


// Task - 5
// window.alert("PIZZA \n PIZZ \n PIZ  \n PI");


// Task - 6
// Email = "shahsadiq208@gmail.com";
// window.alert("My email is " + " " + Email);


// Task - 7
// Book = "A Smarter\n way to learn JavaScript";
// window.alert("I'm Trying to learn from this Book " + Book);


// Task - 8
// document.write("Yah! I can Write HTML content through JavaScript" + "<br>")

// Task - 9
// document.write("\n“▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬”")



//                      Chapter - 3 Variables for Numbers

// Task - 1
// var age = 21 ;
// alert("My age is : " + String(age));

// Task - 2 
// var NUmberOFTrack=21;
// alert("You have Visited this site"+" " + String(NUmberOFTrack) + " " + "times");

// Task - 3
// var birthYear=1998;
// document.write("My birth year is " + " " + String(birthYear) + "<br>" +"Data Type of my declare variable is number");

// Task - 4
// var Visitors_name = "JohnDoe";
// var Product_title = "T- Shirt";
// var Quantity = 5;
// document.write(Visitors_name + " Ordered  " + Quantity + "   " + Product_title + "     " + "  on XYZ Clothing store")


//                      Chapter - 4 

// Task - 1 

// var var1 , var2 ,var3;

// Task - 2

// Legal Variables
// var Name;
// var Age
// var $Address;
// var Percentage;
// var _grade;


//   //illegal Varibles
// var @Name;
// var /Age
// var 1Address;
// var .Percentage;
// var =Grade;


// Task - 3 
// document.write("<h1> “Rules for naming JS variables”</h1> <br>")
// document.write("Letters,$ and _  <br>")
// document.write("Letters,$ or _  <br>")
// document.write("Variables name are case sensitive  <br>")
// document.write("Variable names should not be JS variable  <br>")




//                      Chapter - 5

// Task - 1

// num1 = 10;
// num2 = 20;
// Add = num1 + num2
// document.write("1.Sum of the" + " " + String(num1) + " " + "and" + " " + String(num2) + " " + "is :" + " " + String(Add))



// Task - 2

// num1 = 10;
// num2 = 20;
// Sub = num1 - num2
// Mul = num1 * num2
// Div = num1 / num2
// Mode = num1 % num2
// document.write("1. Subtraction of the" + " " + String(num1) + " " + "and" + " " + String(num2) + " " + "is :" + " " + String(Sub) + "<br>")

// document.write("2. Multiplication of the" + " " + String(num1) + " " + "and" + " " + String(num2) + " " + "is :" + " " + String(Mul) + "<br>")
// document.write("3.Division of the" + " " + String(num1) + " " + "and" + " " + String(num2) + " " + "is :" + " " + String(Div) + "<br>")
// document.write("4.Module of the" + " " + String(num1) + " " + "and" + " " + String(num2) + " " + "is :" + " " + String(Mode) + "<br>")



// Task - 3
// num1 = 5;

//         document.write("Value after variable declaration is Undefine ??")
//         document.write("<br>")
//         document.write("<br>")

//         document.write("Initial Value is " + " " + String(num1));



//         document.write("<br>")
//         document.write("<br>")
//         num1++
//         document.write("The Value of variable after  increment is" + " " + String(num1));



//         document.write("<br>")
//         document.write("<br>")
//         num1 = num1 + 7
//         document.write("The Value of variable after increment  of 7 is" + " " + String(num1));


//         document.write("<br>")
//         document.write("<br>")


//         num1--
//         document.write("The Value of variable after decrement is" + " " + String(num1));
//         document.write("<br>")
//         document.write("<br>")

//         document.write("The Reminder is" + " " + String(num1 % 3));
//         document.write("<br>")

// Task - 4
// var ticketPrice = 600;

// var FIveTickets = ticketPrice * 5;

// document.write("Total cost of buying 5 tickets is  " + String(FIveTickets))



// Task - 5

// document.write("Table of  10 ")

// document.write("<br>")


// var n1 = 10 * 1;
// var n2 = 10 * 2;
// var n3 = 10 * 3;
// var n4 = 10 * 4;
// var n5 = 10 * 5;
// var n6 = 10 * 6;
// var n7 = 10 * 7;
// var n8 = 10 * 8;
// var n9 = 10 * 9;
// var n10 = 10 * 10;

// document.write(
//     String(n1) + " * " + "1" + " = " + String(n1) + "<br>" +
//     String(n2) + " * " + "2" + " = " + String(n2) + "<br>" +
//     String(n3) + " * " + "3" + " = " + String(n3) + "<br>" +
//     String(n4) + " * " + "4" + " = " + String(n4) + "<br>" +
//     String(n5) + " * " + "5" + " = " + String(n5) + "<br>" +
//     String(n6) + " * " + "6" + " = " + String(n6) + "<br>" +
//     String(n7) + " * " + "7" + " = " + String(n7) + "<br>" +
//     String(n8) + " * " + "8" + " = " + String(n8) + "<br>" +
//     String(n9) + " * " + "9" + " = " + String(n9) + "<br>" +
//     String(n10) + " * " + "10" + " = " + String(n10) + "<br>"
// )


// Task - 6

// celsius = 50;
// Far = 70;


// F = (celsius * 9 / 5) + 32;
// document.write("Temprature Celsius into Fahrenheit  " + F + " 'NNoC' ")

// document.write("<br>")
// C = (Far * 9 / 5) + 32;
// document.write("Temprature Fahrenheit into Celsius " + C + " 'NNoF' ")

// Task - 7
// priceItem1 = 650;
// priceItem2 = 100;

// QuantityItem1 = 3;
// QuantityItem2 = 7;


// ShippingCharges = 100;


// totalCost = (priceItem1 * QuantityItem1) + (priceItem2 * QuantityItem2) + ShippingCharges;

// document.write("Total Cost of your Order is " + String(totalCost))

// Task - 8

// TM = 980;
// OM = 804;
// per = OM / TM * 100;
// document.write("Total marks : " + String(TM) + " <br>")
// document.write("Obtained marks : " + String(OM) + " <br>")
// document.write("Percentage" + String(per + " %"))

// Task - 9

// USDOllars = 10 * 104.80;
// Riyal = 10 * 28;

// document.write("10 Dollars is equal to " + String(USDOllars) + " Pakistani Rupees" + "<br>")
// document.write("10 Piyals is equal to  " + String(Riyal) + " Pakistani Rupees")

// document.write("<h1>Currency in PKR</h1>")
// var TotalCurr = USDOllars + Riyal;
// document.write("Total Currency in PKR " + TotalCurr)



// Task - 10

// Expression = 5 * 10 / 2;
// document.write(Expression)

// Task - 11

// CurrentYear = 2020;
//         BirthYear = 1998;
//         Age = 2020 - 1998;


//         document.write("Current Year is :" + String(CurrentYear));
//         document.write("<br>");
//         document.write("Birth Year is :" + String(BirthYear));
//         document.write("<br>");

//         document.write("Your Age is : " + String(Age));


// Task - 12
// var Radius = 20;
// var pi = 3.142;
// var COC = 2 * pi * Radius;
// var Area = pi * Radius * Radius;


// document.write("Radius of Circle is : " + String(Radius));
// document.write("<br>");

// document.write("Circumference of Circle is : " + String(COC));
// document.write("<br>");

// document.write("Area of Circle is : " + String(Area));
// document.write("<br>");


// Task - 13
// FavSnack = "Chocolate Chip";
// CUrrectAge = 15;
// EstimatedAge = 65;
// AmoutOFSnacks = 3;


// TOtalSNacks = (EstimatedAge - CUrrectAge) * AmoutOFSnacks;
// document.write("Favoriate Snacks is : " + FavSnack + "<br>")
// document.write("Estimated Age is : " + EstimatedAge + "<br>")
// document.write("Current Age   is : " + CUrrectAge + "<br>")
// document.write("Amount of Snacks Per day is : " + AmoutOFSnacks + "<br>")

// document.write("You Will Need " + String(TOtalSNacks) + "  " + FavSnack + " to Last your untill the riped old age of " + EstimatedAge);


//                      Chapter - 6 - 9

// Task - 1
// a = 10;

// document.write("Result" + "<br>" + "The value of a is : " + String(a))
// document.write("<br>")

// document.write(".......................................................");

// document.write("<br>")
// document.write("<br>")
// ++a
// document.write("The Value of a++ is " + " " + String(a));

// document.write("<br>")
// document.write("<br>")
// a++
// document.write("The Value of a++ is " + " " + String(a));

// document.write("<br>")
// document.write("<br>")
// --a
// document.write("The Value of --a is " + " " + String(a));

// document.write("<br>")
// document.write("<br>")
// a--
// document.write("The Value of a-- is " + " " + String(a));


// Task - 2
// document.write("--a :  The Value of a is 2, and the condition is --a before pre decrement so value will be 1 <br>")

// document.write(" --a - --b;  The Value of a is 2, and the condition is--a before pre decrement so value will be 1 then b ia 1 it is also pre decrement so value will be 0. <br> After getting 1 and 0 so both will be subtract 1 - 0 = 1. Answer will be 1 <br>")

// document.write(" --a - --b + ++b; The Value of a is 2, and the condition is--a before pre decrement so value will be 1 then b ia 1 it is also pre decrement so value will be 0. <br>After getting 1 and 0 so both will be subtract 1 - 0 = 1 then++b the value of b will be 2 then 1 will be add with 2 so answer will be 3.<br>")

// document.write("--a - --b + ++b + b--; The Value of a is 2, and the condition is--a before pre decrement so value will be 1 then b ia 1 it is also pre decrement so value will be 0. < br >After getting 1 and 0 so both will be subtract 1 - 0 = 1 then++b the value of b will be 2 then 1 will be add with 2 so answer will be 3 Now post decrement in b Now b will be 0 so 3 will be add with 0 < b > Answer will be 3 < /b>")


// Task - 3
// var user = prompt("Enter Your name :")

// document.write("Welcome to  " + user)


// Task - 4

// var x = parseInt(prompt("Enter a number For print a Table:"));
// document.write("======================================" + "<br>")
// document.write("============== " + "Table of  " + String(x) + "  ===============" + "<br>")
// document.write("======================================" + "<br>")
// var i;
// if (x == 5) {

//     var n1 = 5 * 1;
//     var n2 = 5 * 2;
//     var n3 = 5 * 3;
//     var n4 = 5 * 4;
//     var n5 = 5 * 5;
//     var n6 = 5 * 6;
//     var n7 = 5 * 7;
//     var n8 = 5 * 8;
//     var n9 = 5 * 9;
//     var n10 = 5 * 10;

//     document.write(String(n1) + "<br>" + String(n2) + "<br>" + String(n3) + "<br>" + String(n4) + "<br>" + String(n5) + "<br>" + String(n6) + "<br>"
//         + String(n7) + "<br>" + String(n8) + "<br>" + String(n9) + "<br>" + String(n10) + "<br>");

// }


// else {
//     var n1 = x * 1;
//     var n2 = x * 2;
//     var n3 = x * 3;
//     var n4 = x * 4;
//     var n5 = x * 5;
//     var n6 = x * 6;
//     var n7 = x * 7;
//     var n8 = x * 8;
//     var n9 = x * 9;
//     var n10 = x * 10;

//     document.write(String(n1) + "<br>" + String(n2) + "<br>" + String(n3) + "<br>" + String(n4) + "<br>" + String(n5) + "<br>" + String(n6) + "<br>"
//         + String(n7) + "<br>" + String(n8) + "<br>" + String(n9) + "<br>" + String(n10) + "<br>");
// }


// Task - 5  --- SIr Please Run this code on .html file... I Created with passive hard work.After learn the dump i will use this in tables.

/* <script>
var Sub1 = prompt("Enter your Subject 1")

var mark1 = +prompt("Enter your sub1 marks out of 100")


var Sub2 = prompt("Enter your Subject 2")
var mark2 = +prompt("Enter your sub2 marks out of 100")


var Sub3 = prompt("Enter your Subject 3")
var mark3 = +prompt("Enter your sub3 1marks out of 100")

var Tmarks = 300;

var marks = mark1 + mark2 + mark3;


var per = (marks / Tmarks) * 100;
</script>

<table>
<tr>
    <th>Subject</th>
    <th>Total Marks</th>
    <th>Obtained Marks</th>
    <th>Percentage</th>

</tr>

<tr>
    <td>English</td>
    <td>100</td>
    <td>
        <script>
            document.write(String(Sub1) + "  marks is  " + String(mark1));
        </script>
    </td>
    <td>
        <script>
            document.write("Percentage is " + String(mark1 / 100) * 100 + " %");
        </script>

    </td>

</tr>

<tr>
    <td>Urdu</td>
    <td>100</td>
    <td>
        <script>
            document.write(String(Sub2) + "  marks is  " + String(mark2));
        </script>
    </td>
    <td>
        <script>
            document.write("Percentage is " + String(mark2 / 100) * 100 + " %");
        </script>

    </td>

</tr>

<tr>
    <td>Math</td>
    <td>100</td>
    <td>
        <script>
            document.write(String(Sub3) + "  marks is  " + String(mark3));
        </script>
    </td>
    <td>
        <script>
            document.write("Percentage is " + String(mark3 / 100) * 100 + " %");
        </script>

    </td>

</tr>

<br>
<tr>
    <td></td>
    <th>
        <script>
            document.write(String(Tmarks))
        </script>
    </th>

    <th>

        <script>
            document.write(String(marks))
        </script>
    </th>
    <th>
        <script>
            document.write(String(per) + "%")
        </script>

    </th>

</tr>


</table> */


//                      Chapter - 9 - 11

// Task - 1

// var city = prompt("Enter a city");
// if (city == "Karachi") {
//     document.write("Welcome to the City of light")
// }

// Task - 2

// var Gender = prompt("Enter a Gender");
// if (Gender == "Male") {
//     document.write("Good Morning Sir")
// }
// else {
//     document.write("Good Morning Maa'm")

// }


// Task - 3
// var SignalColor = prompt("Enter a Signal Color");
// if (SignalColor == "Red") {
//     document.write("Must Stop")
// }
// else if (SignalColor == "Yellow") {
//     document.write("Ready to Move")

// }
// else {
//     document.write("Move Now")
// }




// Task - 4

// var RemainFuel = +prompt("Enter a Remail Fuel Color");
// if (RemainFuel == 0.25) {
//     document.write('“Please refill the fuel in your car”')
// }


// Task - 5

// var a = 4;
// if (++a === 5) {


//     alert(" Q5 : given condition for variable a is true");
// }

// var b = 82;
// if (b++ === 83) {
//     alert("Q5 : given condition for variable b is true");
// }

// var c = 12;
// if (c++ === 13) {
//     alert("Q5 : condition 1 is true");
// }

// if (c === 13) {
//     alert("Q5 : condition 2 is true");
// }
// if (c === 14) {
//     alert("Q5 :condition 4 is true");
// }
// var materialCost = 20000;
// var laborCost = 2000;
// var totalCost = materialCost + laborCost;
// if (totalCost === laborCost + materialCost) {
//     alert("The cost equals");
// }
// if (true) {
//     alert("True");
// }
// if (false) {
//     alert("False")
// }
// if ("car" < "cat") {
//     alert("car is smaller than cat");
// }



// Task - 6

// TM=300;

//     document.write("Total Marks : " + TM)
//     document.write("<br>");
//     OM=219;

//     document.write("Obtained Marks : " + OM);
//     document.write("<br>");

//     Per=219/300*100;

//     document.write("Percentage : " + Per + "%" );
//     document.write("<br>");
//     if (Per>=80)
//     {
//         document.write("Grade : A-1");
//         document.write("<br>");
//         document.write("Remakrs : Excellent")
//     }
//     else if(Per>=70)
//     {
//         document.write("Grade : A")
//         document.write("<br>");
//         document.write("Remakrs: Good")

//     }
//     else if(Per>=60)
//     {
//         document.write("Grade : B")
//         document.write("<br>");
//         document.write("Grade : A-1")

//     }
//     else if(Per>=50)
//     {
//         document.write("Grade : C")
//         document.write("<br>");
//         document.write("Remarks : You Need to Improve")

//     }
//     else if(Per>=40)
//     {
//         document.write("Grade : D")
//         document.write("<br>");
//         document.write("Remakrs: Sorry")

//     }
//     else
//     {
//         document.write("Fail")}




// Task - 7
// no=+prompt("Enter a number between 1 to 10")
// guessNum=4;
// if (no==guessNum){
//     document.write("“Bingo! Correct Answer")

// }
// else if (no==(guessNum+1))
// {

//     document.write("“Close enough to the correct answer")

// }
// else{
//     document.write(" Wrong answer")
// }



// Task - 8

// no= +prompt("Enter a number")
// if (no%3==0)
// {
//     document.write("It is Divisible by 3")
// }
// else{
//     document.write("It is not Divisible by")
// }


// Task - 9
// no= +prompt("Enter a number")
// if (no%2==0)
// {
//     document.write("It is Even Number")
// }
// else{
//     document.write("It is Odd number")
// }

// Task - 10
// Temp=+prompt("Enter a temprature")
// if (Temp>=40)
// {
//     document.write("It is too hot outside");

// }
// else if(Temp>=30)
// {
//     document.write("The Weather today is Normal")

// }
// else if(Temp>=20)
// {
//     document.write("Today’s Weather is cool")

// }
// else 
// {
//     document.write("“OMG! Today’s weather is so Cool.")
// }

// Task - 11
// no1=+prompt("Enter a First Number");
//     no2=+prompt("Enter a Second Number");

//     Add= no1 + no2;
//     Sub=no1-no2;
//     Mul=no1*no2;
//     Div=no1/no2;
//     Mod=no1%no2;


//     document.write("Addition of Two number is :  " + String(Add) + "<br>");


//     document.write("Subtraction of Two number is :  " + String(Sub) + "<br>");

//     document.write("Multiply of Two number is :  " + String(Mul) + "<br>");

//     document.write("Division of Two number is :  " + String(Div) + "<br>");

//     document.write("Module of Two number is  : " + String(Mod) + "<br>");


//                      Chapter - 12 - 13


// Task - 1
// character = prompt("Enter a string")
// if (character == character.toUpperCase()) {

//     document.write(character + "  is Upper Case ")
// } else if (character == character.toLowerCase()) {

//     document.write(character + "  is lower  Case ")

// }




// // Task - 2
// no1=+prompt("Enter a First Number");
//         no2=+prompt("Enter a Second Number");

//         if (no1>no2)
//         {
//             document.write(String(no1) + "  is Greater than " + String(no2));
//         }

//         else if (no1==no2){
//             document.write(String(no1) + "  is equal to " + String(no2));

//         }
//         else{
//         document.write(String(no2) + "  is Greater than " + String(no1));
//         }


// Task - 3
// no1=+prompt("Enter a First Number");

// if (no1>0)
// {
//     document.write(String(no1) + "  is Positive");
// }

// else if (no1<0){
//     document.write(String(no1) + "  is Negative");

// }
// else if (no1==0){
//     document.write(String(no1) + "  is Zero");}


// Task - 4
// Letter=prompt("Enter a one Letter ");

// if (Letter=='a' | Letter=="e"  | Letter=="e"  | Letter=="e" | Letter=="e" | Letter=="e" | Letter=="e")
// {
//     document.write(String(Letter) + " is Vowel");
// }
// else 
// {
//     document.write(String(Letter) + "  is not Vowel");

// }

// Task - 5
// CorrectPassWord="Sadiq";
// Pass=prompt("Enter Your Password ");

// if (Pass==CorrectPassWord)
// {
//     document.write(" “Correct! The password you entered matches the original password”");
// }
// else 
// {
//     document.write("Incorrect! The password you entered  doesnot matches the original password");

// }

// Task - 6

// var hrs=13;  
// if (hrs<18)
// {
//     document.write(" “Good Day”");
// }
// else 
// {
//     document.write("Good Evening");

// }
// Task - 7

// time=+prompt("Enter an Hours  Like 1900 : ")
//     if (time>=0000 && time<1200)
//     {
//        document.write("Good Morning !")
//     }
//     else if(time>=1200 && time<1700)
//     {
//         document.write("Good Afternoon !")
//     }
//     else if(time>=1700 && time<2100)
//     {
//         document.write("Good Evening !")
//     }
//     else if(time>=2100 && time<2359)
//     {
//         document.write("Good Evening !")
//     }
//     else{
//         document.write("Sorry Invalid Input")
//     }

//                      Chapter - 14 - 16

// Task - 1 
// StdNames = [];

// Task - 2
// StdNames=();

// Task - 3
// StringArray = ["Doll", "Cat", "Meat"]

// Task- 4
// NumberArray = [12, 56, 76]

// Task- 5
// var BooleanArray = [true, false];


// Task- 6
// var MixedArray = [true, false, "Doll", "Cat", "Meat", 12, 56, 76];


// Task - 7
// EduQuali = ['SSC', 'HSC', "BCS", "BS", "BCOM", "MS", "M.Phil", "PhD"];
// document.write(EduQuali[0] + "<br>")
// document.write(EduQuali[1] + "<br>")
// document.write(EduQuali[2] + "<br>")
// document.write(EduQuali[3] + "<br>")
// document.write(EduQuali[4] + "<br>")
// document.write(EduQuali[5] + "<br>")


// Task - 8
// var names = ["Sadiq", 'Faisal', "Shahdad"];
// var Score = [300, 400, 270];

// document.write("Score of " + names[0] + " is " + String(Score[0]) + " Percentage is : " + (Score[0] / 500 * 100) + "%")
// document.write("<br>")
// document.write("Score of " + names[1] + " is " + String(Score[1]) + " Percentage is : " + (Score[1] / 500 * 100) + "%")
// document.write("<br>")
// document.write("Score of " + names[2] + " is " + String(Score[2]) + " Percentage is : " + (Score[2] / 500 * 100) + "%")


// Task - 9 a)
// colorName = [];
// Color = prompt("Enter a Color : ")
// colorName.unshift(Color);
//document.write(colorName)

// Task - 9 b)

// Color = prompt("Enter a Color : ")

// colorName.push(Color);
// document.write(colorName)


// Task - 9 c)
// Color1 = prompt("Enter a Color : ")
// Color2 = prompt("Enter a Color : ")

// colorName.unshift(Color1);
// colorName.unshift(Color2);
// document.write(colorName)

// Task - 9 d)
// colorName.shift();
// document.write(colorName);


// Task - 9 e)
// colorName.pop();
// document.write(colorName);

// Task - 9 f)
// index = +prompt("Enter a Location  : ")
// colorname = prompt("Enter a color name")

// colorName.splice(index, 0, colorname);
// document.write(colorName)

// Task - 9 g)  COnfused ! 

// Task- 10
// StudentScore = [320, 230, 480, 120];

// StudentScore.sort();
// document.write(StudentScore)



// Task- 11
// CityNames = ["karachi", "Lahore", "Islamabad", "Queeta", "Peshawar"];

// var selectedCities = CityNames.splice(2, 2);

// document.write(selectedCities)


// Task - 12
// var arr = ["This", "is", "my", "cat"]

// document.write(arr)

// arr.join();
// document.write(arr)


// Task - 13
// var arr = ["Keyboard", "Mouse", "Printer", "Monitor"]

// document.write("Deveices: " + arr + "<br>")

// a = arr.shift(0);
// document.write("out : " + "<br>" + a + "<br>");

// b = arr.shift(1);

// document.write("out : " + "<br>" + b + "<br>");

// c = arr.shift(2);
// document.write("out : " + "<br>" + c + "<br>");


// d = arr.shift(3);
// document.write("out : " + "<br>" + d + "<br>")


// Task - 14

// var arr = ["Keyboard", "Mouse", "Printer", "Monitor"]

// document.write("Deveices: " + arr + "<br>")

// a = arr.shift(0);
// document.write("out : " + "<br>" + a + "<br>");

// b = arr.shift(1);

// document.write("out : " + "<br>" + b + "<br>");

// c = arr.shift(2);
// document.write("out : " + "<br>" + c + "<br>");


// d = arr.shift(3);
// document.write("out : " + "<br>" + d + "<br>")


// Task - 15
// var Mobiles = ["Apple", "Samsung", "Motorola", "Nokia", "Sony", "Haier"]
// document, write("<select>")
// for (var i = 0; i < Mobiles.length; i++) {
//     document.write("<option>" + Mobiles[i] + "</option>")
// }
// document.write("</select>")

//                      Chapter - 17 - 20

// Task - 1
// numbers = [
//     [],
//     []
// ]

// numbers = [
//     [
//         [],
//         []
//     ],
//     [
//         [],
//         []
//     ]
// ];

// Task - 2
// var no = [
//     [0, 1, 2, 3],
//     [1, 0, 1, 2],
//     [2, 1, 0, 1]

// ];
// for (var i = 0; i < no.length; i++) {
//     document.write(no[i] + "<br>");
// }


// Task - 3
// for (i = 0; i <= 10; i++) {

//     document.write(i + "<br>")
// }

// Task - 4
// table = +prompt("Enter a table : ")
// len = +prompt("Enter a length of a table")
// for (var i = 1; i <= len; i++) {
//     document.write(table + " X " + i + " = " + table * i + "<br>")

// }


// Task - 5
// var fruits = ["apple", "banana", "mango", "orange",
// " strawberry"
// ]

// for (var i = 0; i < fruits.length; i++) {
// document.write(fruits[i], "<br>")
// }
// document.write("<br>")

// for (var i = 0; i < fruits.length; i++) {
// document.write("Element at index   " + i + " is " + fruits[i] + "<br>")
// }

// Task - 6


// a)

// document.write("<br>a. Counting <br><br> ")
// for (var i = 1; i <= 15; i++) {
//     document.write(i, ",")
// }

// document.write("<br>")


// b)

// document.write("<br>b. Reverse Counting <br><br>")
// for (var i = 10; i >= 1; i--) {
//     document.write(i, ",")
// }


// document.write("<br>")

// c)

// document.write("<br>c. Even <br><br>")
// for (var i = 0; i <= 20; i++) {
//     if (i % 2 == 0) {
//         document.write(i, ",")

//     }}

// d)


// document.write("<br>")

// document.write("<br>d. Odd <br><br>")
// for (var i = 0; i <= 20; i++) {
//     if (i % 2 != 0) {
//         document.write(i, ",")

//     }

// }

// e)

// document.write("<br>")
// document.write("<br>e. Series <br><br>")
// for (var i = 1; i <= 20; i++) {
//     if (i % 2 == 0) {
//         document.write(i, "k ,")

//     }

// }

// Task - 7
// items = ["cake", "apple pie", "cookie", "chips", "patties"]

// user_input = prompt("Welcome to ABC bakery ! What do you want to order Sir/Mam'm");

// if (items.indexOf(user_input) !== -1) {
//     document.write(user_input + "  is Available at " + items.indexOf(user_input))
// } else {
//     document.write(user_input + "  is not  Available in out bakery ")

// }

// Task - 8
// var numbers = [24, 53, 78, 91, 12];
// document.write("Array Items :  " + numbers + "<br>")

// var maxValue = Math.max.apply(null, numbers);

// document.write("Largest Number :  " + "  " + maxValue + '<br>'); 



// Task - 9
// var numbers = [24, 53, 78, 91, 12];
// document.write("Array Items :  " + numbers + "<br>")

// var minValue = Math.min.apply(null, numbers);

// document.write("Smallest Number :  " + "  " + minValue + '<br>');


// Task - 10
// for (var i = 1; i <= 50; i++) {
//     document.write(5 * i, ",")
// }
